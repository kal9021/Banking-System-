
from bank.Customer import Customer

print("\n$$$ --- Welcome to the Banking App --- $$$\n")

def get_input(prompt):
    '''Attempt to capture user input with exception handling'''
    option = None
    try:
        option = int(input(f"{prompt}"))
        return option
    except:
        print("Please input a valid option")
        exit()


def search_accounts(customers: list, accountNumber: str):
    found_account = False
    for customer in customers:
        if customer.account._accountNumber == accountNumber:
            print(customer.account, type(customer.account))
            found_account = True
            break
    if found_account:
        print("Found ", customer.account)
        return customer.account
    else:
        print("could not find your account, please try again")
        return None

def authenticate_customer(customers):
    '''
    Attempt to authenticate customer by either creating a bank account
    or loging in an existing customer
    '''
    print("Please select an option to continue ")
    print("1. Open an account,\n2. Login to your account.\n3. Exit App\n")
    option = get_input("option: ")

    if option == 1:
        name = input("please enter your full name: ")
        new_customer = Customer(name)
        new_customer.account_create()
        customers.append(new_customer)
        print("\nPlease login to continue: ")
        new_customer.account_login()
        return new_customer
    elif option == 2:
        name = input("please enter your full name: ")

        # search the list of customers for existing customer
        found_account = False
        for customer in customers:
            if customer == Customer(name):
                found_account = True
                break
        if found_account == False:
            print("could not find your account, please try again")
            exit()
        else:
            customer.account_login()
            return customer
    elif option == 3:
        print("Exiting the program...")
        exit()

    else:
        print("invalid option")
        return


def bank_session(customer: Customer, customers: list):
    # instance of an account object for the customer
    account = customer.account

    # start a session that will allow user to perfom activities on the bank account
    while True:
        print("\n1. View account Balance\n2. Withdraw Money\n3. Deposit Money\n4. Transfer Funds")
        print("5. Exit session\n")
        choice = get_input("select option: ")

        if choice == 1:
            # view balance
            print("="*100)
            print(f"Your account balance is: ${account.accountBalance}")
            print("="*100)

        elif choice == 2:
            # withdraw funds
            print("-"*100)
            amount = float(get_input("please enter amount to withdraw: "))
            account.withdraw(amount)
            print("-"*100)

        elif choice == 3:
            # deposit funds
            print("+"*100)
            amount = float(get_input("please enter amount to deposit: "))
            account.deposit(amount)
            print("+"*100)

        elif choice == 4:
            # transfer funds
            print("*"*100)
            acc_numb = input("enter account number for the receiving account: ")
            amount = float(get_input("please enter the amount to transfer: "))
            recv_account = search_accounts(customers, acc_numb)

            try:
                account.transfer(amount, recv_account)
            except:
                print("Service Not Available. Try Again Later!")

            print("*"*100)

        elif choice == 5:
            print("^"*100)
            print("Exiting your banking session...")
            print("Thank you for banking with us!\n")
            print("^"*100)
            break

        else:
            print("invalid choice")


if __name__ == '__main__':
    customers = list()
    while True:
        customer = authenticate_customer(customers)
        bank_session(customer, customers)
