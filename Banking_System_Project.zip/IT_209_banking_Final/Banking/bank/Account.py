"""
Base Class
"""
from abc import ABC, abstractmethod

class Account(ABC):
    def __init__(self, accountNumber):
        self._accountNumber = accountNumber
        self._accountBalance = 0
    
    # getters for Account class properties

    @property
    def accountNumber(self):
        return self._accountNumber

    @property
    def accountBalance(self):
        return self._accountBalance

    # setters for Account class properties

    @accountBalance.setter
    def accountBalance(self, accountBalance):
        self._accountBalance = accountBalance

    
    def deposit(self, amount):
        # check the amount to deposit
        if amount > 0:
            print(f"Deposit Amount : ${amount:.2f}")
            self._accountBalance += amount
            print(f"New Balance: ${self._accountBalance:.2f}")
        else:
            print("please deposit an amount greater than 0")

    def transfer(self, amount, recv_account):
        if recv_account == None:
            print("Transfer failed - receiving account not found")
            return
        else:
            print(f"transfering ${amount} to {recv_account}")
            
        # check amount
        transfer_fee = 0.12 * amount
        if (amount+transfer_fee) <= self._accountBalance:
            # deduct the amount and fee from the current balance
            self._accountBalance -= (amount+transfer_fee)

            # set the account balance of the receiving account
            recv_account._accountBalance += amount
            print(f"Transfer Complete: New Balance ${self._accountBalance:.2f}")
        else:
            print("Transfer failed - insufficient balance")

    # abstract methods to be defined in child classes

    @abstractmethod
    def withdraw(amount):
        pass

    # string representation of the Account class
    def __str__(self):
        return f"<Account: {self.accountNumber}, ${self.accountBalance:.2f}>"

    # equality compare method
    def __eq__(self, o):
        if o is not None:
            return self.accountNumber == o.accountNumber
        return False
   
