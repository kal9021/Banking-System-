"""
Checking account to extend Account
"""

from bank.Account import Account

class CheckingsAccount(Account):

    def __init__(self, accountNumber):
        super().__init__(accountNumber)
        self.__transactionFee = None


    def _calculateTransactionFee(self, widthdrawAmount):
        if widthdrawAmount < 2000:
            self._transactionFee = 20
        elif widthdrawAmount < 20000:
            self._transactionFee = 93
        elif widthdrawAmount < 200000:
            self._transactionFee = 166
        else:
            self._transactionFee = 332

    def withdraw(self, amount):
        # set and get the transcation fee
        self._calculateTransactionFee(amount)
        fee = self._transactionFee

        print(f"Withdraw Amount: ${amount:.2f}")
        # check the withdrawal amount
        if (amount+fee) <= self._accountBalance:
            print(f"Transaction Fee: ${fee}")
            self._accountBalance -= amount
            self._accountBalance -= fee
            print(f"New Balance: ${self._accountBalance:.2f}")
        else:
            print("insufficient balance - cannot withdraw")

if __name__ == "__main__":
    acc = CheckingsAccount("1197848886")
    acc.accountBalance = 1000
    acc.deposit(2000)
    acc.withdraw(4450)
    print(acc)

