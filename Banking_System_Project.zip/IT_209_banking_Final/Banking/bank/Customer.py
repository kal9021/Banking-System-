"""
Customer to interface with the application
"""
from getpass import getpass
from hashlib import sha256
import random

from bank.CheckingsAccount import CheckingsAccount
from bank.SavingsAccount import SavingsAccount


class Customer:
    def __init__(self, name):
        self.name = name
        self.account = None
        self.account_no = None
        self.account_pin = None

    def account_create(self):
        print("Available Account types\n\n1. Savings Account\n2. Checkings Account\n")
        
        acc_type = None
        try:
            acc_type = int(input("please select account type (1 or 2): "))
        except:
            print("please select a valid option (1 or 2)")
            exit()

        account_name = input("enter a desired account name: ")
        account_pin = getpass("create 4+ digits account pin: ")
        account_no = "11" + "".join([str(ord(c)) for c in random.sample(self.name.upper(), 4)])

        self.account_no = account_no
        self.account_pin = sha256(account_pin.encode()).hexdigest()
        self.account = SavingsAccount(self.account_no) if acc_type == 1 else CheckingsAccount(self.account_no)

        print("Congratulations! Created your ",end ="\n")
        print("savings ", end="") if acc_type == 1 else print("checking ", end="")
        print(f"account {account_name} with account number {account_no}")
        print("Thank you for banking with us!")

    def account_login(self):
        account_number = input("enter your account number: ")
        account_pin = getpass("enter your account pin: ")
        hashed_pin = sha256(account_pin.encode()).hexdigest()

        if account_number == self.account_no and hashed_pin == self.account_pin:
            print("Login successful")
        else:
            print("Invalid login credentials")

    def __str__(self):
        return f"<Customer: {self.name}, {self.account_no}>"

    def __eq__(self, o):
        return self.name == o.name


if __name__ == "__main__":
    customer = Customer("Fahad")
    custome2 = Customer("Fahad")
    print(customer == custome2)
    customer.account_create()
    customer.account_login()
    print(customer)
    
    