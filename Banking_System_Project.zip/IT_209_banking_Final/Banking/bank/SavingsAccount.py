"""
Savings Account based on Account
"""

from bank.Account import Account

class SavingsAccount(Account):

    def __init__(self, accountNumber):
        super().__init__(accountNumber)
        self._interestRate= None

    @property
    def interestRate(self):
        return self._interestRate

    @interestRate.setter
    def interestRate(self, baseRate):
        self._interestRate = baseRate

    def _calculateInterest(self):
        return self._accountBalance * self._interestRate

    def applyInterest(self):
        interest = self._calculateInterest()
        print(f"Interest Earned: ${interest:.2f}")
        self.deposit(interest)

    def withdraw(self, amount):
        print(f"Withdraw Amount: ${amount:.2f}")
        # check the withdrawal amount
        if amount <= self._accountBalance:
            self._accountBalance -= amount
            print(f"New Balance: ${self._accountBalance:.2f}")
        else:
            print("insufficient balance - cannot withdraw")
            

if __name__ == "__main__":
    acc = SavingsAccount("1197848886")
    acc.accountBalance = 1000
    acc.deposit(2000)
    acc.withdraw(450)
    acc.interestRate = 1.4
    acc.applyInterest()
    acc.withdraw(6220)
    print(acc)



